# Publicación coordinada

1. Crear un repositorio público separado para Vivienda_Peru y subir este árbol completo a main. No modificar el visor Democracia.
2. En Settings / Pages, seleccionar GitHub Actions como fuente. El workflow valida los datos y publica docs.
3. Iniciar sesión en Zenodo, abrir GitHub, sincronizar repositorios y activar el repositorio Vivienda_Peru. Si la autorización existente requiere ampliar acceso, confirmarlo antes de aceptar nuevos permisos.
4. Verificar .zenodo.json y CITATION.cff; crear la release v1.0.2 con el commit validado. Publicar después de activar la integración.
5. Verificar el archivo de la release en Zenodo, anotar DOI de versión y conceptual, y comprobar su resolución. No generar un DOI manual distinto como sustituto silencioso de la integración solicitada.
6. Incorporar los identificadores confirmados a publication.json, CITATION.cff y documentación en un commit posterior. El visor consulta publication.json y mostrará los enlaces reales. La release archivada sigue siendo el snapshot del commit original.
7. Adjuntar el protocolo a un registro OSF adecuado, declarando expresamente que la línea base ya estaba analizada. La preparación o carga en un proyecto no se comunica como prerregistro ni como registro formal sin comprobar su estado.
8. Registrar el commit, la etiqueta, las URLs y la resolución del DOI en el informe de publicación. No afirmar éxito a partir de intentos de envío o botones pulsados.
