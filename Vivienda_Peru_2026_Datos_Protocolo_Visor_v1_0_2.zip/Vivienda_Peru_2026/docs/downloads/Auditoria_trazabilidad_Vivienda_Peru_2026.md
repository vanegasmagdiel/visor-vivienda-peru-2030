# Auditoría de trazabilidad científica Vivienda Perú 2026

Investigación independiente del Dr. Magdiel Torres Vanegas.

Autor: Dr. Magdiel Torres Vanegas. ORCID 0000-0002-7913-214X.
Fecha de auditoría: 2026-10-30. Corte de evidencia: 2026-10-26. Versión: 1.0.2.

## Dictamen

Procede publicar una base documental descriptiva con trazabilidad explícita y un visor reproducible. La trazabilidad se confirma para las afirmaciones delimitadas en H01 a H12, con niveles de acceso y verificación distintos por fuente. No se certifica validez causal, revisión independiente, agotamiento de fuentes ni auditoría de ejecución física de programas.

La base contiene 9 fuentes oficiales nucleares, 76 observaciones, 7 cálculos derivados y 12 hallazgos vinculados. El conteo de fuentes no equivale a nueve corroboraciones independientes: varias proceden del mismo sector y algunas notas replican la misma familia de registros.

## Evidencia numérica y acceso

- D02: PDF íntegro disponible y huella SHA-256 registrada. Se contrastan las 63 celdas de ENAPRES 2018-2024 con los cuadros originales.
- D03: cifras y localizador comprobados mediante lectura web de la fuente oficial; la descarga local íntegra devolvió 403. No se declara preservación de sus bytes.
- D04 y D05: fichas oficiales verificadas en texto web. La descarga local devolvió HTTP 200 con contenido que no era PDF; se rechaza esa respuesta como copia válida.
- D06: nota primaria identificada y cantidades corroboradas en El Peruano, que reproduce el registro sectorial; esto no es una segunda medición independiente.
- D07: cupo y fecha contrastados en publicación oficial y campaña de la convocatoria.
- D08: cifra corroborada en el Fondo Mivivienda, con nota del 10 de julio frente al 9 de julio de la nota MVCS.
- D09: título y fecha corroborados en el índice oficial PNVR. Solo se incorpora el umbral “más de 6900”; no se incorporan detalles del cuerpo no preservado desde el original.

## Correcciones y restricciones preservadas

1. El BFH reportado el 25/12/2025 se codifica R. No se presenta como cierre al 31/12 ni como vivienda concluida.
2. El cupo CSP es hasta 14 880 y Wasiymi es más de 6 900; se preservan operadores y no se sustituyen por conteos exactos.
3. Las colocaciones 2026 corresponden al primer semestre. No se anualizan ni se agregan a bonos de otro año.
4. Los componentes de déficit se definen mediante “y/o”; no se obliga a que su suma reconstruya el total. La razón 8,0/10,1 es una relación entre porcentajes redondeados.
5. Todas las estimaciones rurales de déficit cuantitativo 2018-2024 se marcan referenciales por precisión, no solo la de 2024.
6. Los años 2020 y 2021 conservan la advertencia de cambios de levantamiento.
7. El 5,77 % de seguimiento PNVU no se fusiona con 2,1 % nacional. La ficha 3699 orienta los metadatos de población, sin demostrar igualdad de procedimientos.
8. ISPN y razones de seguimiento mantienen sus universos. No se suman ni se recalculan como un índice de capacidad estatal.
9. Ninguna prueba de integridad automatizada se presenta como validación independiente del contenido científico.

## Reproducción e integridad

Ejecutar `python scripts/validate.py` desde la raíz. Los CSV, JSON y SQLite deben conservar los mismos registros y claves; los derivados se recalculan desde observaciones. El libro XLSX permite revisar los cálculos mediante fórmulas. El archivo SHA256SUMS verifica identidad de los entregables, no verdad empírica de las fuentes.

## Alcance editorial y científico

El manuscrito de base conserva declaraciones de correspondencia, financiamiento, conflictos y originalidad pendientes de confirmación personal del autor. No se deposita el manuscrito como artículo publicado ni preprint en este paquete. Los datos y el visor son un producto derivado con sus propias condiciones de citación.

La publicación en OSF de este protocolo sería un registro retrospectivo de la línea base y un plan prospectivo de ampliación. No puede presentarse como prerregistro del análisis ya realizado. No se afirma que el DOI de Zenodo o el identificador OSF existan antes de la confirmación de los servicios.
