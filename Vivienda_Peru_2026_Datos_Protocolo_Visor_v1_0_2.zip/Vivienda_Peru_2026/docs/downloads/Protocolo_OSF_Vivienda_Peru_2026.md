# Protocolo documental y plan de ampliación de Vivienda y habitabilidad en el Perú

## Identificación y estado temporal

Investigación independiente del Dr. Magdiel Torres Vanegas.

Vivienda y habitabilidad en el Perú hacia 2030. Protocolo de documentación y ampliación del estudio de caso de política pública. Autor: Dr. Magdiel Torres Vanegas, Universidad Nacional de Trujillo, Escuela de Posgrado, Unidad de Ciencias Económicas, programas de Gestión Pública; Estudios Axial Perú E.I.R.L. ORCID 0000-0002-7913-214X. Versión 1.0.2, fecha 2026-10-30. El análisis de línea base ya fue realizado. Este documento registra retrospectivamente sus decisiones y especifica prospectivamente la ampliación. No es un prerregistro del manuscrito ya desarrollado.

## Pregunta y objetivo

Pregunta: ¿qué correspondencia existe entre las necesidades habitacionales, los instrumentos públicos y la evidencia disponible de implementación y resultados de habitabilidad en el Perú? Objetivo: documentar y hacer reproducible la relación necesidad-instrumento-producto-resultado, preservando población, geografía, periodo, método y madurez de evidencia. La extensión futura evaluará si nuevos registros permiten cerrar los enlaces actualmente no observados.

## Diseño y unidades de análisis

Estudio de caso documental descriptivo y analítico con síntesis de datos agregados. Unidad sustantiva: la correspondencia entre necesidad, instrumento y resultado observable. Unidad de registro: una observación definida por indicador, año, ámbito y fuente. Unidad documental: norma, reporte, ficha técnica o comunicación oficial. No hay participantes reclutados, experimento, aleatorización, microdatos personales ni diseño de identificación causal en la línea base.

## Línea base y corpus

Corte sustantivo: 26 de octubre de 2026. Auditoría y consolidación: 30 de octubre de 2026. Nueve fuentes oficiales D01-D09, 76 observaciones: 63 celdas ENAPRES 2018-2024, cinco métricas PNVU 2025, un indicador programático de déficit y siete registros de instrumentos. Las 19 referencias académicas del manuscrito contextualizan método y discusión; no se cuentan como observaciones empíricas ni corroboraciones independientes. La selección fue intencional, no una revisión sistemática exhaustiva.

## Localización y selección de nuevos documentos

La extensión conservará una bitácora con fecha, institución, repositorio, consulta literal, filtros, URL, documento candidato, decisión y motivo. Fuentes prioritarias: INEI, MVCS y sus programas, Fondo Mivivienda, CEPLAN y MEF. Consultas dirigidas: déficit habitacional ENAPRES; PNVU seguimiento; PP 0146 indicadores 3699 y 3702; BFH desembolsos; Crédito Mivivienda; PNVR Wasiymi. Se incluirán documentos oficiales con definición y periodo reconocibles. Se excluirán duplicados, piezas sin fuente identificable y estimaciones no comparables presentadas como continuidad de serie. No se imputarán conteos de búsqueda retrospectivos.

## Extracción y modelo de datos

Se usarán claves source_id, indicator_id y observation_id. Cada registro contendrá valor numérico, unidad, operador, año, periodo, ámbito, población, base del indicador, fuente y localizador, estatus de evidencia, bandera de calidad y límite de inferencia. Los identificadores se mantienen en actualizaciones. Las fuentes disponen de fecha de verificación, modalidad de acceso y, cuando los bytes fueron obtenidos válidamente, SHA-256. Un enlace verificable no se declarará copia archivada. Los campos desconocidos permanecen nulos con su motivo; no se convierten en cero.

## Clasificación de evidencia y comparabilidad

O: observación estadística publicada; S: seguimiento oficial; R: registro comunicado; P: acumulado parcial; C: cupo convocado; PR: programación o anuncio. R no acredita cierre anual. La comparabilidad exige examinar constructo y método, universo, denominador, geografía y periodo. Se mantendrán separados los hogares nacionales ENAPRES y el seguimiento urbano NSE C, D y E. Los conteos de bonos, créditos y viviendas no se agregarán como beneficiarios únicos sin enlace de registros y regla de deduplicación.

## Análisis definido para la línea base

Se calcularán diferencias de porcentajes en puntos porcentuales y razones aritméticas entre valores publicados, con fórmulas e identificadores de entrada. No se ejecutarán pruebas de significación ni intervalos sin microdatos y diseño muestral. No se forzará la suma de componentes cualitativo y cuantitativo. Los valores rurales cuantitativos conservarán la condición referencial y 2020-2021 la advertencia de levantamiento. Las métricas CEPLAN se describirán con sus denominadores; no se recombinarán como medición propia de capacidad estatal.

## Plan prospectivo de ampliación

La ampliación comenzará con una nueva versión fechada, sin modificar silenciosamente la línea base. Se buscarán registros agregados por territorio e instrumento con presupuesto programado y ejecutado, desembolso, culminación, ocupación y condiciones posteriores de vivienda y entorno. Antes de cualquier comparación causal se definirán tratamiento, población elegible, ventana temporal, resultado y estrategia de identificación en una enmienda independiente. La futura actualización no tiene calendario automático ni supone datos ya disponibles. El horizonte 2030 es de política pública; este paquete no genera pronósticos numéricos.

## Control de calidad y revisión humana

Los chequeos verifican claves, tipos, referencias, rangos, razones, concordancia entre formatos y enlaces locales. Las 63 celdas ENAPRES se contrastan con el texto del PDF oficial descargado. Los demás datos se contrastan documentalmente y su método de acceso se declara. No hay evidencia de doble extracción independiente; no se informa acuerdo intercodificador. Una segunda revisión futura debe identificar revisor, fecha, discrepancia y resolución; un resultado de pruebas automáticas no sustituye esa revisión.

## Ética, integridad y licencias

Se utilizan fuentes públicas y valores agregados. No se publican datos personales ni se afirma autorización de comité de ética. Código original bajo MIT; documentación, estructura de la compilación y narrativas propias bajo CC BY 4.0; los documentos y datos de terceros conservan su atribución y condiciones. Las copias completas de fuentes externas no se redistribuyen en el repositorio. Se declara uso de asistencia de IA en documentación y programación, sin inventar observaciones. Financiamiento y conflictos personales se declararán por el autor; no se infieren de sus afiliaciones.

## Versionado y cadena de publicación

GitHub alojará la fuente, el visor y los datos; la versión se identificará mediante commit y etiqueta. Zenodo archivará la release mediante la integración GitHub previamente activada, generando un DOI de versión y un DOI conceptual. El protocolo y los metadatos deben existir antes de la release. El DOI se incorporará al visor y a la citación solo después de verificar el registro publicado; no se reutiliza el DOI de Democracia Perú 2030. El protocolo OSF enlazará el DOI y el commit cuando estén emitidos. Un archivo subido a un proyecto OSF no equivale por sí solo a un registro OSF.

## Metadatos para OSF

Título: Vivienda y habitabilidad en el Perú hacia 2030 Protocolo documental y plan de ampliación. Tipo: registro retrospectivo de estudio documental y protocolo prospectivo de actualización. Componentes: protocolo, diccionario, auditoría, referencia a datos y código. Estado al preparar el paquete: protocolo generado, sin identificador OSF asignado. Si se registra, se debe declarar que los datos y resultados de línea base ya eran conocidos. No utilizar la etiqueta de revisión sistemática ni el formulario PRISMA como descripción de este diseño.

## Fuentes y anexos de respaldo

La matriz fuentes.csv y observaciones.csv identifica los nueve documentos primarios y sus localizadores. hallazgos.csv conecta afirmaciones con observaciones; calculos.csv explicita entradas y operación. referencias.md conserva las 28 referencias del manuscrito base. La auditoría documenta límites de acceso y correcciones. El checksum de la versión permite comprobar que el protocolo, la base y el visor corresponden al mismo paquete.
