# Referencias del artículo de base

Acevedo-De-los-Ríos, A., Chumpitaz-Requena, F. R., & Rondinel-Oviedo, D. R. (2024). Analysis of urban metabolism in an informal settlement using the MuSIASEM method in Lima. Cleaner Environmental Systems, 13, 100189.
https://doi.org/10.1016/j.cesys.2024.100189

Acevedo-De-los-Ríos, A., Jones-Pérez, J., & Rondinel-Oviedo, D. R. (2025). Methodology for prioritizing sustainable urban regeneration interventions in informal settlements: Case study in Lima. Cities, 157, 105550.
https://doi.org/10.1016/j.cities.2024.105550

Bowen, G. A. (2009). Document analysis as a qualitative research method. Qualitative Research Journal, 9(2), 27–40.
https://doi.org/10.3316/QRJ0902027

Brenton, S., Baekkeskov, E., & Hannah, A. (2023). Policy capacity: Evolving theory and missing links. Policy Studies, 44(3), 297–315.
https://doi.org/10.1080/01442872.2022.2043266

Calderón Cockburn, J. (2022). Las ciudades peruanas y la Ley de Desarrollo Urbano Sostenible. Derecho & Sociedad, (59), 1–22.
https://doi.org/10.18800/dys.202202.009

Calderón Cockburn, J. (2026). La política de vivienda social en Perú (2002–2025): evaluación y propuestas alternativas. Discursos del Sur, (17).
https://doi.org/10.15381/dds.n17.34345

Cejudo, G. M., & Trein, P. (2023). Pathways to policy integration: A subsystem approach. Policy Sciences, 56(1), 9–27.
https://doi.org/10.1007/s11077-022-09483-1

Centro Nacional de Planeamiento Estratégico. (2026). Informe anual de políticas nacionales correspondiente al año 2025. 
https://www.minsa.gob.pe/Recursos/OTRANS/09GestionIns/informe/2026/Informe-Anual-de-Pol%C3%ADticas-Nacionales-2025.pdf

Devoto Ykeho, A., Pairazamán Sotelo, F., Vilchez Vargas, X., & Torero Gamero, D. A. (2023). Los parámetros urbanísticos y edificatorios de la Vivienda de Interés Social en Lima Metropolitana: Zonificación exclusionaria y vulneración del derecho a la vivienda. THEMIS Revista de Derecho, (83), 159–184.
https://doi.org/10.18800/themis.202301.009

Díaz Rodríguez, G., & Navarro Fernández, C. (2023). El derecho de acceso a la vivienda en Lima Metropolitana a propósito de la Ley 31313, Ley de Desarrollo Urbano Sostenible y el Proyecto de Reglamento de Vivienda de Interés Social. THEMIS Revista de Derecho, (83), 121–137.
https://doi.org/10.18800/themis.202301.007

González, F., Baeza, F., Valdebenito, R., Sánchez, B. N., Diez-Roux, A., & Vives, A. (2024). Improvements in habitability and housing satisfaction after dwelling regeneration in social housing complexes. The RUCAS study. Social Science & Medicine, 355, 117090.
https://doi.org/10.1016/j.socscimed.2024.117090

Howlett, M., & Ramesh, M. (2023). Designing for adaptation: Static and dynamic robustness in policy-making. Public Administration, 101(1), 23–35.
https://doi.org/10.1111/padm.12849

Instituto Nacional de Estadística e Informática. (2025). Encuesta Nacional de Programas Presupuestales 2024: Capítulo XII Déficit habitacional (pp. 123–125).
https://www.inei.gob.pe/media/MenuRecursivo/publicaciones_digitales/Est/Lib2027/cap12.pdf

Martínez Muñoz, C. A., & Maroto Ramos, F. J. (2022). Urban informality and state intervention: The case of Lima. Cities, 127, 103728.
https://doi.org/10.1016/j.cities.2022.103728

Ministerio de Economía y Finanzas. (2024). Programa Presupuestal 0146: Ficha del indicador de resultado específico 3699. 
https://www.mef.gob.pe/contenidos/presu_publ/ppr/estr_program/PP_0146_RESULTADO_2024.pdf

Ministerio de Economía y Finanzas. (2026). Programa Presupuestal 0146: Ficha del indicador de producto 3702. 
https://www.mef.gob.pe/contenidos/presu_publ/ppr/estr_program/PP_0146_PRODUCTO_2026.pdf

Ministerio de Vivienda, Construcción y Saneamiento. (2021). Decreto Supremo N.° 012-2021-VIVIENDA que aprueba la Política Nacional de Vivienda y Urbanismo al 2030. 
https://www.gob.pe/institucion/vivienda/normas-legales/2022465-012-2021-vi

Ministerio de Vivienda, Construcción y Saneamiento. (2025, 25 de diciembre). ¡Más de 52 mil familias cumplieron el sueño de la casa propia con bonos del Ministerio de Vivienda durante el 2025! 
https://www.gob.pe/institucion/vivienda/noticias/1319698

Ministerio de Vivienda, Construcción y Saneamiento. (2026a, 21 de julio). ¡Más familias protegidas del frío! Ministerio de Vivienda construirá más de 6900 viviendas rurales Wasiymi a diciembre del 2026. 
https://www.gob.pe/institucion/vivienda/noticias/1421394

Ministerio de Vivienda, Construcción y Saneamiento. (2026b, 9 de julio). Ministerio de Vivienda: Más de 4600 familias se beneficiaron con el Crédito Mivivienda durante el primer semestre. 
https://www.gob.pe/institucion/vivienda/noticias/1416790

Ministerio de Vivienda, Construcción y Saneamiento. (2026c, 27 de marzo). Ministerio de Vivienda otorgará bonos a más de 14 mil familias para construir sus casas con Techo Propio. 
https://www.gob.pe/institucion/vivienda/noticias/1371655

Moya, L., Vilela, M., Jaimes, J., Espinoza, B., Pajuelo, J., Tarque, N., Santa-Cruz, S., Vega-Centeno, P., & Yamazaki, F. (2024). Vulnerabilities and exposure of recent informal urban areas in Lima, Peru. Progress in Disaster Science, 23, 100345.
https://doi.org/10.1016/j.pdisas.2024.100345

Najman, M. (2022). Acerca de los efectos de la localización de la nueva vivienda social sobre las luchas por el acceso a la ciudad de los sectores populares. EURE, 48(145).
https://doi.org/10.7764/EURE.48.145.13

Saguin, K., & Howlett, M. (2022). Enhancing policy capacity for better policy integration: Achieving the Sustainable Development Goals in a post COVID-19 world. Sustainability, 14(18), 11600.
https://doi.org/10.3390/su141811600

Trein, P., Fischer, M., Maggetti, M., & Sarti, F. (2023). Empirical research on policy integration: A review and new directions. Policy Sciences, 56(1), 29–48.
https://doi.org/10.1007/s11077-022-09489-9

Villanueva-Paredes, K. S., & Villanueva-Paredes, G. X. (2023). Policies and mechanisms of public financing for social housing in Peru. Sustainability, 15(11), 8919.
https://doi.org/10.3390/su15118919

Vince, J., Fudge, M., Fullbrook, L., & Haward, M. (2024). Understanding policy integration through an integrative capacity framework. Policy and Society, 43(3), 381–395.
https://doi.org/10.1093/polsoc/puae027

Wu, X., Ramesh, M., & Howlett, M. (2015). Policy capacity: A conceptual framework for understanding policy competences and capabilities. Policy and Society, 34(3–4), 165–171.
https://doi.org/10.1016/j.polsoc.2015.09.001


## Recursos de publicación y reproducción añadidos tras el archivo

Estos tres recursos complementan las 28 referencias del manuscrito de línea base; no amplían las nueve fuentes oficiales del corpus empírico.

Torres Vanegas, M. (2026a). *Visor reproducible de vivienda y habitabilidad en el Perú hacia 2030* (versión 1.0.2) [Software]. GitHub. https://github.com/vanegasmagdiel/visor-vivienda-peru-2030/releases/tag/v1.0.2

Torres Vanegas, M. (2026b). *Vivienda y habitabilidad en el Perú hacia 2030 Protocolo documental y plan de ampliación Registro retrospectivo* (versión 1.0.2) [Protocolo]. OSF. https://doi.org/10.17605/OSF.IO/KWMA5

Torres Vanegas, M. (2026c). *Vivienda y habitabilidad en el Perú hacia 2030 Visor y base documental* (versión 1.0.2) [Software y base documental]. Zenodo. https://doi.org/10.5281/zenodo.23829470
