"""Validate the published data package without network or third-party libraries."""
from pathlib import Path
import json, csv, sqlite3, math, re, argparse, hashlib
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--source-pdf');parser.add_argument('--write-report',action='store_true');args=parser.parse_args()
d=json.loads((ROOT/'docs/data/dataset.json').read_text(encoding='utf-8'));checks=[]
def check(name,passed,detail=''):
 checks.append(dict(check=name,passed=bool(passed),detail=detail))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources={s['source_id']:s for s in d['sources']};inds={i['indicator_id']:i for i in d['indicators']};obs={o['observation_id']:o for o in d['observations']};calcs={r['calculation_id']:r for r in d['calculations']}
check('unique_source_ids',len(sources)==len(d['sources']))
check('unique_observation_ids',len(obs)==len(d['observations']))
check('expected_baseline_counts',[len(sources),len(obs),len(calcs),len(d['claims'])]==[9,76,7,12])
check('observation_foreign_keys',all(o['source_id'] in sources and o['indicator_id'] in inds for o in obs.values()))
check('explicit_observation_types',all(type(o['value']) in [int,float] and math.isfinite(o['value']) and type(o['year']) is int for o in obs.values()))
check('percentage_range',all(0<=o['value']<=100 for o in obs.values() if o['unit']=='porcentaje'))
check('no_periodic_forecast',not d['metadata']['forecast_included'] and max(o['year'] for o in obs.values())==2026)
check('threshold_operators_preserved',obs['CSP-C-2026']['operator']=='le' and obs['WAS-PR-2026']['operator']=='gt')
check('administrative_statuses',all(obs[x]['evidence_status']=='R' for x in ['BFH-2025','CSP-2025','AVN-2025','BBP-2025']) and obs['CMV-2026-H1']['evidence_status']=='P')
check('BFH_modality_reconciliation',obs['CSP-2025']['value']+obs['AVN-2025']['value']==obs['BFH-2025']['value'])
check('rural_quantitative_flags',all('referencial_CV_mayor_15' in o['quality_flag'] for o in obs.values() if o['area']=='Rural' and o['indicator_id']=='deficit_cuantitativo'))
check('pandemic_flags',all('cambio_levantamiento_pandemia' in o['quality_flag'] for o in obs.values() if o['source_id']=='D02' and o['year'] in [2020,2021]))
check('non_comparable_groups_separated',obs['EN-Q-N-2024']['comparability_group']!=obs['PNVU-Q-2025']['comparability_group'])
for r in d['calculations']:
 a,b=obs[r['input_a']]['value'],obs[r['input_b']]['value'];expect=a-b if r['operation']=='difference' else a/b*100
 check('recalculate_'+r['calculation_id'],math.isclose(r['value'],expect,rel_tol=1e-9,abs_tol=1e-9))
for o in obs.values():
 if o['numerator'] is not None:check('reported_ratio_'+o['observation_id'],round(o['numerator']/o['denominator']*100,1)==o['value'])
check('claim_links',all(all(x in obs for x in c['observation_ids'].split(';')) and all(x in sources for x in c['source_ids'].split(';')) and all(x in calcs for x in c['calculation_ids'].split(';') if x) for c in d['claims']))
for name,key in [('observaciones','observations'),('fuentes','sources'),('indicadores','indicators'),('calculos','calculations'),('hallazgos','claims'),('diccionario','dictionary')]:
 with (ROOT/f'docs/data/{name}.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
 check('CSV_JSON_'+name,len(rows)==len(d[key]) and all(all(row[k]==('' if v is None else str(v)) for k,v in src.items()) for row,src in zip(rows,d[key])))
con=sqlite3.connect('file:'+str(ROOT/'docs/downloads/Vivienda_Peru_2026.sqlite')+'?mode=ro',uri=True);con.row_factory=sqlite3.Row
check('SQLite_foreign_keys',con.execute('PRAGMA foreign_key_check').fetchall()==[])
check('SQLite_integrity',con.execute('PRAGMA integrity_check').fetchone()[0]=='ok')
for table,key in [('sources','sources'),('indicators','indicators'),('observations','observations'),('calculations','calculations')]:
 rows=[dict(r) for r in con.execute('SELECT * FROM '+table)];pk=list(d[key][0])[0];actual={r[pk]:r for r in rows}
 check('SQLite_JSON_'+table,len(rows)==len(d[key]) and all(actual[r[pk]]==r for r in d[key]))
con.close()
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  for k in ['href','src']:
   if k in a:self.links.append(a[k])
p=Links();p.feed((ROOT/'docs/index.html').read_text(encoding='utf-8'));missing=[]
dynamic_ids=set(sources)
for link in p.links:
 u=urlsplit(link)
 if u.scheme or u.netloc:continue
 if u.path:
  f=(ROOT/'docs'/unquote(u.path)).resolve()
  if not f.is_file() or f.stat().st_size==0:missing.append(link)
 elif u.fragment and u.fragment not in p.ids and u.fragment not in dynamic_ids:missing.append(link)
check('local_downloads_and_assets',not missing,','.join(missing))
js=(ROOT/'docs/data/dataset.js').read_text(encoding='utf-8');embedded=json.loads(js.removeprefix('window.VIVIENDA_DATA = ').rstrip().removesuffix(';'))
check('offline_JS_matches_JSON',embedded==d)
publication=json.loads((ROOT/'docs/publication.json').read_text(encoding='utf-8'))
zen=publication['zenodo'];doi=zen['version_doi']
check('publication_identifiers_consistent',(doi is None and 'doi:' not in (ROOT/'CITATION.cff').read_text()) or (zen['status']=='published' and bool(re.fullmatch(r'10\.5281/zenodo\.[0-9]+',doi or '')) and bool(zen['record_url'])))

# Optional source-level extraction requires the PDF from the official endpoint.
# It is not part of the redistributed archive and is not an independent reviewer.
source_check=dict(performed=False,reason='No se proporcionó PDF oficial local; revisar el informe de auditoría de la edición.')
if args.source_pdf:
 import fitz
 pp=Path(args.source_pdf);pdf=fitz.open(pp);matched=0;problems=[]
 for ind,idx in [('deficit_cuantitativo',2),('deficit_cualitativo',3),('deficit_total',4)]:
  txt=pdf[idx].get_text();txt=txt.split('Cuadro N°')[1].split('Gráfico N°')[0]
  for label,area in [('Total','Nacional'),('Urbana','Urbano'),('Rural','Rural')]:
   m=re.search(r'\n'+label+r'\n(.*?)(?=\n(?:Total|Urbana|Rural|Área|Variación))',txt,re.S)
   if not m:problems.append(ind+'/'+area);continue
   vals=[float(x.replace(',','.')) for x in re.findall(r'(?m)^([0-9]+,[0-9]+)(?: a/)?$',m.group(1))][:7]
   for year,value in zip(range(2018,2025),vals):
    rows=[o for o in obs.values() if o['indicator_id']==ind and o['area']==area and o['year']==year]
    if len(rows)==1 and rows[0]['value']==value:matched+=1
    else:problems.append(f'{ind}/{area}/{year}')
 check('63_ENAPRES_cells_vs_official_PDF',matched==63 and not problems,f'{matched}/63 celdas concordantes; discrepancias: {problems}')
 check('official_PDF_hash',digest(pp)==sources['D02']['source_pdf_sha256'])
 source_check=dict(performed=True,matched_cells=matched,expected_cells=63,sha256=digest(pp),independent_human_review=False)
report=dict(result='passed' if all(x['passed'] for x in checks) else 'failed',check_count=len(checks),checks=checks,source_level_check=source_check,scope='Integridad, congruencia y reproducción de la edición; no validación causal ni revisión independiente.')
if args.write_report:(ROOT/'docs/downloads/VALIDACION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(result=report['result'],checks=len(checks),failures=[x for x in checks if not x['passed']],source_level_check=source_check),ensure_ascii=False))
raise SystemExit(0 if report['result']=='passed' else 1)
