# Vivienda_Peru 1.0.2

Primera línea base reproducible del estudio documental de vivienda y habitabilidad en el Perú. Corte 26/10/2026; consolidación 30/10/2026. Incluye 76 observaciones, 7 cálculos y 12 hallazgos. La referencia Democracia Perú 2030 se utiliza exclusivamente para el estilo del portal. Antes de publicar la release, activar este nuevo repositorio en Zenodo; el DOI será emitido por esa integración y no se anticipa en los metadatos.
